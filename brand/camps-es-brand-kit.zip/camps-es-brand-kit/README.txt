CAMPS.ES brand kit v1.0
logo/ - SVG/PNG/ICO
social/ - макеты
ai-kit/ - DESIGN.md, BRAND.md, SKILL.md
fonts/ - Oswald, Unbounded, Golos Text (SIL OFL)
Онлайн: https://grimaldsociales-prog.github.io/campses/brand/
